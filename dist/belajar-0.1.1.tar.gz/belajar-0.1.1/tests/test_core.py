# Unit tests for core logic
